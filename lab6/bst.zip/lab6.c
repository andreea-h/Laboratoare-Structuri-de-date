

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "lab6helper.h"

node *createNode(int key)
{
    node *newNode = (node *)malloc(sizeof(node));
    newNode->val = key;
    newNode->left = NULL;
    newNode->right = NULL;

    return newNode;
}

/* functia insereaza un node in arbore 
   puteti apela functia createNode care returneaza un struct node
   alocat */

// ex1 - 1p
/* functia insereaza un nod in arbore */
void addnode(node** tree, int val)
{

}

/* cautati o valoare v intr-un arbore binar de cautare, se va intoarce 
	nodul daca exista un nod cu valoarea cautata,
	NULL daca nu exista */
// ex2 - 1p
node* search(node *tree, int val)
{
	return NULL;
}


/* parcurgerea în preordine a arborelui creat, cu afișarea valorilor din noduri*/
// ex3.1 - 0.5p
void preorder(node* tree)
{

}

/* parcurgerea în inordine a arborelui creat, cu afișarea valorilor din noduri*/
// ex3.2 - 0.5p
void inorder(node* tree)
{
     
}

/* parcurgerea in postnordine a arborelui creat, cu afișarea valorilor din noduri*/
// ex3.3 - 0.5p
void postorder(node* tree)
{
          
}

/* functia implementeaza
ștergerea subarborelui unui node oarecare,
prin setarea adreselor de legatură ale fiilor la valoarea NULL 
(doar sub arborele, nu si nodul) */
//  1p
void deleteSubTree(node** tree, int value)
{
	
}

/*
	functia va fi de ajutor pentru stergeri
*/
int isLeaf(node* nod)
{
	return 0;
}

/* 1p ---- functia primeste o valoare iar daca un nod contine valoarea si este frunza,
atunci va sterge nodul din arbore */
void deleteLeaf(node** tree, int value)
{
	
}


/* 
	functia primeste arborele si un nod si intoarce parintele nodului
	functia va fi de ajutor pentru stergerea unui nod din arbore	
 */
node* getParent(node* tree, node* child) {
	return NULL;
}




/* 
	functia gaseste succesorul inordine al radacinii
	si salveaza acest succesor in q
	va fi de folos pentru stererea unui nod
*/
void find_succesor(node** q, node* tree)
{
		
}

/* 2p --- functia sterge un node din arbore */
void deleteNode(node** tree, int value)
{
  
}


/* Compute the "height" of a tree -- the number of
    nodes along the longest path from the root node
    down to the farthest leaf node. - 0.5p*/
int leaf_number(node* tree) 
{
    return 0;
}

/* scrieti o functie care verifica daca un arbore binar este un 
arbore binar de cautare --- 2P */
int is_binary_search_tree(node *tree) {
	return 0;
}



/*
    BONUS
    scrieti o functie care primeste 2 valori si calculeaza cel mai mic stramos
    comun al acestor 2 valori din arbore(se considera ca valorile se gasesc in arbore)
    Exemplu:
    pentru
            20
         /      \
        8       22
      /  \
    4     12
        /    \
        10  14    
    LCA pt 10 si 14 este 12
    LCA pt 14 si 8 este 8
    LCA pt 10 si 22 este 20 
    ---- 2P
*/
int lowest_common_ancestor(node* tree, int val1, int val2)
{
    int lca = -1;
    return lca;
}


int main()
{


    node* tree = NULL;
    addnode(&tree, 14);
    addnode(&tree, 10);
    addnode(&tree, 2);
    addnode(&tree, 3);
    addnode(&tree, 4);
    addnode(&tree, 1);
    addnode(&tree, 13);
    addnode(&tree, 12);
    addnode(&tree, 22);
    addnode(&tree, 16);
    addnode(&tree, 35);
    addnode(&tree, 30);
    addnode(&tree, 40);
    addnode(&tree, 28);

    printTree(tree);
    /*
    node* searchedNode = search(tree, 16);
    assert(searchedNode != NULL);
    assert(searchedNode -> val == 16);
    printf("Nodul cu valoarea 16 exista \n"); 

    searchedNode = search(tree, 12);
    assert(searchedNode != NULL);
    assert(searchedNode -> val == 12);
    printf("Nodul cu valoarea 12 exista \n"); 

    searchedNode = search(tree, 14);
    assert(searchedNode != NULL);
    assert(searchedNode -> val == 14);
    printf("Nodul cu valoarea 14 exista \n"); 

    searchedNode = search(tree, 100);
    assert(searchedNode == NULL);
    printf("Nodul cu valoarea 100 nu exista\n");



    preorder(tree);
    printf("\n"); 

    inorder(tree);
    printf("\n");

    postorder(tree);
    printf("\n");


    printf("deleteSubTree 35\n");
    deleteSubTree(&tree, 35);
    printTree(tree);


    printf("deleteLeaf 10\n");
    deleteLeaf(&tree, 10);
    printTree(tree);
    printf("deleteLeaf 35\n");
    deleteLeaf(&tree, 35);
    printTree(tree);

    
    printf("deleteNode 3\n");
    deleteNode(&tree, 3);
    printTree(tree);
    printf("deleteNode 10\n");
    deleteNode(&tree, 10);
    printTree(tree);
    
    printf("leafNumber %d \n", leaf_number(tree));
    */
    return 0;
}
